package parser

// Generate keywords.go
//go:generate ./genkeyword
