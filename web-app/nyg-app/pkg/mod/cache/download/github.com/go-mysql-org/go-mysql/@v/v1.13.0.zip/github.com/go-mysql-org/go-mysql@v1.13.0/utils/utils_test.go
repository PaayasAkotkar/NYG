package utils

// Will register common flags
import (
	_ "github.com/go-mysql-org/go-mysql/test_util"
)
