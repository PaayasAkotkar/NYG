package nocopy

// Lock ...
func (*NoCopy) Lock() {}

// Unlock ...
func (*NoCopy) Unlock() {}
