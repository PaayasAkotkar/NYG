### What happened?

### What did you expect?

### Minimal graphql.schema and models to reproduce

### versions
 - `go list -m github.com/vektah/gqlparser/v2`?
 - `go version`?

<!--
Please make sure you are using github.com/vektah/gqlparser/v2 as the v1 is no longer supported!
-->

