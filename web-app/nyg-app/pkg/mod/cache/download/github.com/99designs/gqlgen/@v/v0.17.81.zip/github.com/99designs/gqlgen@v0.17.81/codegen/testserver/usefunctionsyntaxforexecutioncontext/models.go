package usefunctionsyntaxforexecutioncontext

type RoleModel string

var (
	RoleModelAdmin RoleModel = "ADMIN"
	RoleModelUser  RoleModel = "USER"
	RoleModelGuest RoleModel = "GUEST"
)
