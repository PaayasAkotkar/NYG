This client is used internally for testing. I wanted a simple graphql client sent user specified queries.

You might want to look at:
 - https://github.com/shurcooL/graphql: Uses reflection to build queries from structs.
 - https://github.com/machinebox/graphql: Probably would have been a perfect fit, but it uses form encoding instead of json...
 - [Khan/genqlient](https://github.com/Khan/genqlient) - Generate go GraphQL client from GraphQL query
 - [infiotinc/gqlgenc](https://github.com/infiotinc/gqlgenc) - Generate go GraphQL client from GraphQL query
 - [Yamashou/gqlgenc](https://github.com/Yamashou/gqlgenc) - Generate go GraphQL client from GraphQL query
